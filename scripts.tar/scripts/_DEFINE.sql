REM
REM *** DEFINE VARIABLES ***
REM

DEFINE CR = "CHR(10)"
DEFINE LF = "CHR(10)"

DEFINE OUTPUT = "c:\temp\output.tmp"
DEFINE SCRIPT = "c:\temp\script.tmp"
DEFINE HELP   = "c:\work\scripts\main\readme.txt"

