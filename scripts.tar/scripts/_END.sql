REM
REM *** THE ENDING SCRIPT ***
REM

SPOOL OFF

PROMPT
PROMPT
PROMPT Output was spooled into file "&OUTPUT"
PROMPT

@_DEFAULT
@_UNDEF

REM @_CONFIRM "exit"
REM EXIT

